﻿using System;

class ChessGame
{
    private static char[,] board = new char[8, 8];
    private static bool isWhiteTurn = true;

    static void Main()
    {
        InitializeBoard();
        PrintBoard();

        while (true)
        {
            Console.WriteLine((isWhiteTurn ? "White's" : "Black's") + " turn.");
            Console.Write("Enter move (e.g., 'e2 e4'): ");
            string[] move = Console.ReadLine().Split(' ');

            if (move.Length != 2)
            {
                Console.WriteLine("Invalid move format. Please try again.");
                continue;
            }

            if (!MovePiece(move[0], move[1]))
            {
                Console.WriteLine("Invalid move. Please try again.");
                continue;
            }

            isWhiteTurn = !isWhiteTurn;
            PrintBoard();
        }
    }

    static void InitializeBoard()
    {
        // Set up initial board configuration
        board[0, 0] = 'r'; board[0, 1] = 'n'; board[0, 2] = 'b'; board[0, 3] = 'q';
        board[0, 4] = 'k'; board[0, 5] = 'b'; board[0, 6] = 'n'; board[0, 7] = 'r';

        board[7, 0] = 'R'; board[7, 1] = 'N'; board[7, 2] = 'B'; board[7, 3] = 'Q';
        board[7, 4] = 'K'; board[7, 5] = 'B'; board[7, 6] = 'N'; board[7, 7] = 'R';

        for (int i = 0; i < 8; i++)
        {
            board[1, i] = 'p';
            board[6, i] = 'P';
        }
    }

    static void PrintBoard()
    {
        Console.WriteLine("\n  a b c d e f g h");
        Console.WriteLine("  ---------------");

        for (int i = 0; i < 8; i++)
        {
            Console.Write(8 - i + "|");

            for (int j = 0; j < 8; j++)
            {
                Console.Write(board[i, j] + " ");
            }

            Console.WriteLine();
        }

        Console.WriteLine("\n  a b c d e f g h\n");
    }

    static bool MovePiece(string from, string to)
    {
        int fromX = from[0] - 'a';
        int fromY = '8' - from[1];
        int toX = to[0] - 'a';
        int toY = '8' - to[1];

        if (fromX < 0 || fromX >= 8 || fromY < 0 || fromY >= 8 || toX < 0 || toX >= 8 || toY < 0 || toY >= 8)
        {
            return false;
        }

        char piece = board[fromY, fromX];
        char targetPiece = board[toY, toX];

        if ((isWhiteTurn && char.IsLower(piece)) || (!isWhiteTurn && char.IsUpper(piece)))
        {
            return false;
        }

        if (targetPiece != '\0' && (char.IsLower(piece) == char.IsLower(targetPiece)))
        {
            return false;
        }

        if (Math.Abs(fromX - toX) <= 1 && Math.Abs(fromY - toY) <= 1)
        {
            board[toY, toX] = piece;
            board[fromY, fromX] = '\0';
            return true;
        }

        return false;
    }
}

